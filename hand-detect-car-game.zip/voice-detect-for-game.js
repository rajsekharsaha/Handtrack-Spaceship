// // Initialize annyang
// if (annyang) {
//   // Add voice command
//   annyang.addCommands({
//     'hello': function() {
//       console.log('Hello World');
//     }
//   });

//   // Start listening for voice commands
//   annyang.start();
// }
// COMING SOON................